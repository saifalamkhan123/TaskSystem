﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TMS.Model;

namespace TMS
{
    public partial class Admin : System.Web.UI.Page
    {
        TMSDBEntities db = new TMSDBEntities();

        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                BindGrid();
                BindStatusDropdown();
            }
        }

        private void BindGrid()
        {
            var tasks = from t in db.Tasks
                        join u in db.Users on t.UserId equals u.UserId
                        join ts in db.TaskStatus on t.Status equals ts.TSId
                        select new
                        {
                            t.TaskId,
                            t.Title,
                            t.Description,
                            ts.TSName,
                            t.DueDate
                        };

            GridView1.DataSource = tasks.ToList();
            GridView1.DataBind();
        }

        private void BindStatusDropdown()
        {
            var statuses = db.TaskStatus.ToList();
            var dropdown = (DropDownList)FormView1.FindControl("StatusDropDownList");
            dropdown.DataSource = statuses;
            dropdown.DataValueField = "TSId";
            dropdown.DataTextField = "TSName";
            dropdown.DataBind();
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            BindGrid();
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            int taskId = (int)GridView1.DataKeys[e.RowIndex].Value;
            var task = db.Tasks.Find(taskId);

            if (task == null)
            {
                // Handle the case where task is not found
                return;
            }

            if (GridView1.Rows.Count > e.RowIndex)
            {
                var row = GridView1.Rows[e.RowIndex];

                if (row.Cells.Count > 0 && row.Cells[0].Controls.Count > 0)
                {
                    var titleTextBox = row.Cells[0].Controls[0] as TextBox;
                    if (titleTextBox != null)
                    {
                        task.Title = titleTextBox.Text;
                    }
                }

                if (row.Cells.Count > 1 && row.Cells[1].Controls.Count > 0)
                {
                    var descriptionTextBox = row.Cells[1].Controls[0] as TextBox;
                    if (descriptionTextBox != null)
                    {
                        task.Description = descriptionTextBox.Text;
                    }
                }

                var statusDropDownList = row.FindControl("StatusDropDownList") as DropDownList;
                if (statusDropDownList != null)
                {
                    task.Status = int.Parse(statusDropDownList.SelectedValue);
                }

                if (row.Cells.Count > 3 && row.Cells[3].Controls.Count > 0)
                {
                    var dueDateTextBox = row.Cells[3].Controls[0] as TextBox;
                    if (dueDateTextBox != null)
                    {
                        task.DueDate = DateTime.Parse(dueDateTextBox.Text);
                    }
                }
            }

            db.SaveChanges();
            GridView1.EditIndex = -1;
            BindGrid();
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            BindGrid();
        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int taskId = (int)GridView1.DataKeys[e.RowIndex].Value;
            var task = db.Tasks.Find(taskId);
            if (task != null)
            {
                db.Tasks.Remove(task);
                db.SaveChanges();
                BindGrid();
            }
        }

        private int GetCurrentUserId()
        {
            if (Session["UserId"] != null)
            {
                return (int)Session["UserId"];
            }
            throw new Exception("User is not logged in.");
        }

        protected void FormView1_ItemInserting(object sender, FormViewInsertEventArgs e)
        {
            try
            {
                int userId = GetCurrentUserId();
                var userExists = db.Users.Any(u => u.UserId == userId);
                if (!userExists)
                {
                    throw new Exception("User does not exist.");
                }

                var titleTextBox = (TextBox)FormView1.FindControl("TitleTextBox");
                var descriptionTextBox = (TextBox)FormView1.FindControl("DescriptionTextBox");
                var statusDropDownList = (DropDownList)FormView1.FindControl("StatusDropDownList");
                var dueDateTextBox = (TextBox)FormView1.FindControl("DueDateTextBox");

                if (titleTextBox != null && descriptionTextBox != null && statusDropDownList != null && dueDateTextBox != null)
                {
                    var task = new Task
                    {
                        Title = titleTextBox.Text,
                        Description = descriptionTextBox.Text,
                        Status = int.Parse(statusDropDownList.SelectedValue),
                        DueDate = DateTime.Parse(dueDateTextBox.Text),
                        UserId = userId
                    };

                    db.Tasks.Add(task);
                    db.SaveChanges();
                    BindGrid();
                }
                else
                {
                    throw new Exception("One or more controls are not found.");
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }
    }
}
