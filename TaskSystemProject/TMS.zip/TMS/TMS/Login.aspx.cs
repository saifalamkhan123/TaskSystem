﻿using System;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Entity;
using TMS.Model;

namespace TMS
{
    public partial class Login : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblError.Visible = false;
                
                txtUsername.Text = "admin";
                txtUsername.Focus();
                
            }
                          
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            using (var context = new TMSDBEntities())
            {
                var user = context.Users
                                  .Include(u => u.Role) // Include Role navigation property
                                  .FirstOrDefault(u => u.Username == username && u.Password == password);

                if (user != null)
                {
                    Session["UserId"] = user.UserId;
                    Session["userName"] = user.Username;
                    if (user.RoleId == 2)
                    {
                        Response.Redirect("Admin.aspx");
                    }
                    else if (user.RoleId == 1)
                    {
                        Response.Redirect("User.aspx");
                    }
                    // Add more roles as needed
                }
                else
                {
                    lblError.Text = "Invalid username or password";
                    lblError.Visible = true;
                }
            }
        }
    }
}
